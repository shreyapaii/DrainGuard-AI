"""DrainGuard AI core package."""
